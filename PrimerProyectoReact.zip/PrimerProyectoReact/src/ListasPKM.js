import React, { useState, useEffect } from 'react';

function ListasPKM() {
  // almacena todos los nombres de los Pokémon de la API
  const [todosPokemon, setTodosPokemon] = useState([]);

  // almacena los nombres de los Pokémon seleccionados
  const [pokemonSeleccionado, setPokemonSeleccionado] = useState([]);

  // almacena el índice de los pokemon
  const [siguienteIndice, setSiguienteIndice] = useState(0);

  // guarda la imagen del Pokémon seleccionado
  const [imagenPokemonSeleccionado, setImagenPokemonSeleccionado] = useState('');

  // guarda el nombre del Pokémon seleccionado
  const [nombrePokemonSeleccionado, setNombrePokemonSeleccionado] = useState('');

  // el useEffect hace las solicitudes a la api
  useEffect(() => {
    // Realiza la solicitud a la API de Pokemon
    fetch('https://pokeapi.co/api/v2/pokemon/')
      .then(response => response.json()) // Convierte la respuesta a un objeto JSON
      .then(data => {
        // Extrae los nombres de los Pokémon del objeto JSON con map y crea un array para almacenarlos
        const nombres = data.results.map(pokemon => pokemon.name);
        setTodosPokemon(nombres);
      });
  }, []);

  // Esta función se ejecuta al pulsar en el botón "+"
  function agregarPokemon() {
    // Si se han seleccionado todos los Pokémon, no hace nada
    if (siguienteIndice >= todosPokemon.length) {
      return;
    }

    // Crea un nuevo array y copia los elementos del array anterior hasta el índice seleccionado
    const nuevoPokemonSeleccionado = [...pokemonSeleccionado, todosPokemon[siguienteIndice]];
    //selecciona un nuevo Pokémon de la lista, aumentando el índice del siguiente Pokémon en 1
    setPokemonSeleccionado(nuevoPokemonSeleccionado);
    setSiguienteIndice(siguienteIndice + 1);


// hace una solicitud de API utilizando el siguiente índice incrementándolo en uno para obtener
// los datos del nuevo Pokémon
    fetch(`https://pokeapi.co/api/v2/pokemon/${siguienteIndice + 1}`)
    //lo convierte en JSON
      .then(response => response.json())
      .then(data => {
        //actualiza la imagen y el nombre del pokemon
        setImagenPokemonSeleccionado(data.sprites.front_default);
        setNombrePokemonSeleccionado(data.name);
      });
//elimina el pokemon seleccionado de la lista de todos los pokemons mostrados, y actualiza el estado de la aplicación 
    setTodosPokemon(todosPokemon.filter(pokemon => pokemon !== todosPokemon[siguienteIndice]));
  }

  //decrementa la variable del índice y actualiza el estado para mostrar el pokemon correspondiente
  function quitarPokemon() {
    if (siguienteIndice <= 0) {
      return;
    }
    setPokemonSeleccionado(pokemonSeleccionado.slice(0, -1));
    setSiguienteIndice(siguienteIndice - 1);

    fetch(`https://pokeapi.co/api/v2/pokemon/${siguienteIndice}`)
      .then(response => response.json())
      .then(data => {
       //actualiza la imagen y el nombre del pokemon
        setImagenPokemonSeleccionado(data.sprites.front_default);
        setNombrePokemonSeleccionado(data.name);
      });
      // Se agrega el último Pokémon seleccionado a la lista de todos los Pokémon
    setTodosPokemon([...todosPokemon, pokemonSeleccionado[pokemonSeleccionado.length - 1]]);
  }
  return (
    <div>
      <div>
        <h2>Aumenta el contador para descubrir el Pokémon</h2>
      </div>
      <div className="contador">
 
        <button onClick={quitarPokemon}>-</button>
        <span>{siguienteIndice}</span>
        <button onClick={agregarPokemon}>+</button>
      </div>
      {imagenPokemonSeleccionado && (
        <div>
          <p>Te ha tocado: {nombrePokemonSeleccionado}</p>
          <img src={imagenPokemonSeleccionado} alt="Pokémon seleccionado" />
        </div>
      )}
      <div>
        <h2>Consíguelos a todos</h2>
      </div>    
      <div className="listas">
        <div>
          <h3>Pokémon por capturar</h3>
          <ul>
            {todosPokemon.map(nombre => <li key={nombre}>{nombre}</li>)}
          </ul>
        </div>
        
        <div>
          <h3>Pokémon capturados</h3>
          <ul>
            {pokemonSeleccionado.map(nombre => <li key={nombre}>{nombre}</li>)}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default ListasPKM;
